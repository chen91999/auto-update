# -*- coding: utf-8 -*-
"""
无尽冬日自动上车 - 核心逻辑（可热更新）
============================================
本文件是可热更新的核心：修改后打成 update.zip（含本文件 + 可选资源），
放进 exe 旁的 update 文件夹，点 GUI「更新」按钮即生效，无需重新打包 exe。

- 截图/识别：MaaFramework v5（Encode 截图 + 模板匹配找加号 + OCR 车头名/标题，GPU 加速）
- 点击：sendevent 直写 /dev/input/event4（游戏过滤合成触摸，只响应驱动级事件）
- 配置：config.txt（勾选的车头即白名单），全不勾 = 所有集结都加

逻辑（与命令行版一致）：
  主循环：
    1. 判定是否在集结页（①"联盟战争"标题 OCR ②"集结"标签背景色 #E1EFF2 双判定）
    2. 不在集结页 → 找主界面"联盟"字样 → 点联盟 → 点联盟战争 → 回判定
    3. 在集结页 → 找绿色加号（模板匹配+颜色验证）→ OCR 车头名 → 命中白名单 → 直接点击加号
       → 进入选择队伍界面 → 1-4 队选无感叹号 → 点出征 → 弹窗处理 → 返回
"""
import os
import sys
import json
import re
import time
import queue
import threading
import subprocess
import numpy as np

from maa.resource import Resource
from maa.controller import AdbController
from maa.tasker import Tasker
from maa.pipeline import JRecognitionType, JTemplateMatch, JOCR
from maa.define import MaaAdbScreencapMethodEnum, MaaAdbInputMethodEnum

# 核心版本号（每次修改代码时递增；GUI 启动时显示，更新包可携带新版本）
CORE_VERSION = "2026.10.12a"

# ==========================================================
# 路径与配置
# ==========================================================
# ---- 路径（源码运行与 exe 打包适配）----
# 资源目录：源码=脚本目录；打包后=exe 解压出的临时目录（模板/模型/pipeline 打进 exe 内）
# 热更新后=exe 所在目录（更新包把新资源放到 exe 旁，本文件也随之在 exe 旁）
RES_DIR = os.path.dirname(os.path.abspath(__file__))
# 运行目录：源码=脚本目录；打包后=exe 所在目录（config.txt/run_log.txt 持久化，重开不丢）
if getattr(sys, "frozen", False):
    RUN_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    RUN_DIR = RES_DIR
BASE_DIR = RUN_DIR   # 兼容旧引用（run_log.txt 等）

# 资源路径：优先 exe 旁（热更新后放的新资源），找不到再退回内置（exe 解压目录）
def _pick(rel):
    p = os.path.join(RUN_DIR, rel)
    if os.path.exists(p):
        return p
    return os.path.join(RES_DIR, rel)

PIPE_DIR = os.path.dirname(_pick("pipeline.json"))                        # pipeline.json 所在目录
MODEL_DIR = os.path.dirname(_pick(os.path.join("model", "ocr", "det.onnx")))  # OCR 模型
TPL_FILE = _pick("plus_green.png")                                        # 绿色加号模板
CONFIG_FILE = os.path.join(RUN_DIR, "config.txt")  # 白名单/adb 配置（.txt 避免被 MaaFw 当 pipeline 加载）
STOP_FILE = os.path.join(RUN_DIR, "stop.txt")       # 存在即停止

# 日志图标配色（行首图标 → 颜色）
LOG_ICON_COLORS = {
    "✅": "#1a7f37",   # 成功-绿
    "❌": "#d93025",   # 错误-红
    "⚠": "#c96a1a",    # 警告-橙
    "🔍": "#1a73e8",   # 找到-蓝
    "📋": "#0f766e",   # 车头-青
    "🚗": "#0d9488",   # 上车-蓝绿
    "⏹": "#888888",   # 停止-灰
    "📐": "#7c3aed",   # 判定-紫
    "⏱": "#1a73e8",   # 定时器-蓝
    "💾": "#1a73e8",   # 保存-蓝
    "🔄": "#2563eb",   # 重建-蓝
    "👆": "#2563eb",   # 下滑-蓝
    "⚪": "#9aa0a6",   # 跳过-灰
}

# GUI 日志显示：emoji 图标 → 可染色文本符号（tkinter 无法给 emoji 上色，用符号替代）
ICON_TEXT_MAP = {
    "✅": "[√]", "❌": "[×]", "⚠": "[!]", "🔍": "[找]",
    "📋": "[名]", "🚗": "[车]", "⏹": "[停]", "📐": "[判]",
    "⏱": "[时]", "💾": "[存]", "🔄": "[连]", "👆": "[滑]", "⚪": "[跳]",
}

# 坐标/颜色配置（与 AutoJs6 auto_work.js CFG 一致）
CFG = {
    # ---- 集结页判定 ----
    "PAGE_TITLE_REG": (78, 11, 237, 67),   # "联盟战争"标题 OCR 区域 (x1,y1,x2,y2)
    "PAGE_BG_REG": (50, 105, 89, 136),     # "集结"标签背景色区域
    "PAGE_BG_RGB": (225, 239, 242),        # 目标背景色 #E1EFF2
    "PAGE_BG_TOL": 25,

    # ---- 导航：主界面 → 联盟 → 联盟战争 ----
    "MAIN_LM_REG": (498, 1228, 574, 1272),  # 主界面"联盟"字样 OCR 区
    "MAIN_LM_TAP": (533, 1252),             # 主界面"联盟"按钮点击
    "LMZ_TAP": (198, 669),                  # "联盟战争"按钮点击

    # ---- 队伍选择（队1~队4）----
    "TEAMS": [(64, 118), (138, 123), (212, 118), (287, 126)],
    "EXCL_POINTS": [(81, 102), (155, 102), (229, 102), (303, 102)],  # 感叹号采样点
    "EXCL_RGB": (255, 150, 2),              # 感叹号橙黄色
    "EXCL_TOL": 30,

    # ---- 出征 / 弹窗 / 详情页 ----
    "GO_TAP": (555, 1217),                  # 出征按钮
    "POPUP_REG": (70, 491, 653, 845),       # 士兵超上限弹窗 OCR 区
    "DETAIL_REG": (251, 165, 307, 197),     # 详情页"队长"OCR 区（备用）

    # ---- 车头识别 ----
    "PLUS_SEARCH_REG": (560, 162, 141, 964),  # 找绿色加号区域 (x,y,w,h)
    "PLUS_THRESHOLD": 0.7,
    "PLUS_MAX": 3,                            # 最多匹配 3 个加号
    "PLUS_GREEN_CHECK": (-12, -12),           # 加号颜色采样点相对中心偏移
    "PLUS_NAME_REL": (-354, -136, 49, -86),   # 名字区相对加号中心偏移 (dx1,dy1,dx2,dy2)
    "JOIN_TAP": (598, 510),                   # 点加号后进入选队伍页按钮

    # ---- 等待时间（毫秒）----
    "SCROLL_INTERVAL": 10000,   # 每 10 秒下滑一次
    "PAGE_CHECK_INTERVAL": 5000,  # 每 5 秒判定一次是否还在集结页
    "WAIT_NAV": 300,            # 导航点击间等待
    "WAIT_AFTER_JOIN": 50,      # 上车成功后等待
    "WAIT_POPUP": 10,           # 点出征后等弹窗
    "WAIT_SCROLL": 50,          # 下滑后等待

    # ---- 触摸驱动 ----
    "TOUCH_DEV": "/dev/input/event4",
}

DEFAULT_CONFIG = {
    "adb_path": r"C:\Program Files\NetEase\MuMu\nx_main\adb.exe",
    "address": "emulator-5554",
    "whitelist": [],   # 勾选的车头白名单，空 = 所有集结都加
    "names": [],       # 全部填写的车头名字（含未勾选，用于界面恢复）
    "win_w": 880,      # GUI 窗口宽度（下次启动记住）
    "win_h": 640,      # GUI 窗口高度（下次启动记住）
    "win_preview_h": 230,  # 特效预览窗口高度（下次启动记住）
    "scroll_interval_s": 10.0,   # 下滑间隔（秒）
    "page_check_interval_s": 5.0,  # 集结页判定间隔（秒）
    "update_url": "",   # 更新包下载地址（可选）
}

# 日志线程安全队列（工作线程 → GUI）
LOG_QUEUE = queue.Queue()
# 点击特效队列（工作线程 → GUI）：(最近一帧 numpy BGR 图, x, y)
TAP_QUEUE = queue.Queue()


# ==========================================================
# 日志
# ==========================================================
def now_ts():
    return time.strftime("%H:%M:%S", time.localtime()) + "." + str(int(time.time() * 1000) % 1000).zfill(3)


def log(msg):
    line = f"[{now_ts()}] {msg}"
    print(line, flush=True)
    try:
        with open(os.path.join(BASE_DIR, "run_log.txt"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
    try:
        LOG_QUEUE.put(line)
    except Exception:
        pass


# ==========================================================
# 配置加载/保存
# ==========================================================
def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                user = json.load(f)
            cfg.update({k: v for k, v in user.items() if k in cfg})
            log(f"✅ 已加载配置: {CONFIG_FILE}")
        except Exception as e:
            log(f"⚠️ 配置加载失败({e})，使用默认配置")
    else:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        log("配置不存在，已新建 config.txt")
    return cfg


def save_config(whitelist, names=None, timers=None, update_url=None):
    """保存车头配置：whitelist=勾选的（上车用），names=全部填写的（界面恢复用），
    timers=(下滑间隔秒,集结页判定秒)，update_url=更新包下载地址"""
    cfg = load_config()   # 读取现有 adb 配置
    cfg["whitelist"] = whitelist
    if names is not None:
        cfg["names"] = names
    if timers is not None:
        cfg["scroll_interval_s"], cfg["page_check_interval_s"] = timers
    if update_url is not None:
        cfg["update_url"] = update_url
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    log(f"💾 已保存配置: {len(whitelist)} 个车头 → {', '.join(whitelist) if whitelist else '（全部集结都加）'}"
        + (f"，已记录 {len(names)} 个名字" if names is not None else ""))


# ==========================================================
# 核心逻辑（与命令行版一致）
# ==========================================================
class AutoJoin:
    def __init__(self, cfg):
        self.cfg = cfg
        self.stop = False
        self.whitelist = [w.strip() for w in cfg.get("whitelist", []) if w.strip()]
        if self.whitelist:
            log(f"✅ 车头白名单({len(self.whitelist)}个): {', '.join(self.whitelist)}")
        else:
            log("未勾选任何车头：所有集结都加")
        self._tid = 1000
        self.last_frame = None   # 最近一帧截图（点击特效用）
        self._last_preview_push = 0.0   # 预览帧推送节流

        # ---- 常驻 adb shell 连接（提速）----
        self._shell_proc = None          # 常驻交互式 shell 进程
        self._reader_thread = None       # stdout 读线程
        self._out_q = None               # 读线程输出队列
        self._persist_fallback = False   # True=常驻失败，退回单次模式
        self._shell_fail_count = 0
        self._conn_ever = False          # 是否已建立过常驻连接（区分首次/重建）

        # ---- MaaFramework 初始化 ----
        log("初始化 MaaFramework...")
        self.res = Resource()
        self.res.post_pipeline(PIPE_DIR).wait()
        log("加载 OCR 模型...")
        self.res.post_ocr_model(MODEL_DIR).wait()
        log("连接 ADB...")
        self.ctrl = AdbController(
            adb_path=cfg["adb_path"], address=cfg["address"],
            screencap_methods=MaaAdbScreencapMethodEnum.Encode,
            input_methods=MaaAdbInputMethodEnum.Null,   # 点击用 sendevent，不用 MaaFw 输入
        )
        self.ctrl.post_connection().wait()
        self.tasker = Tasker()
        self.tasker.bind(self.res, self.ctrl)
        log(f"✅ 连接成功: {cfg['address']}")

    # ---------- 基础工具 ----------
    def capture(self):
        """MaaFw 截图，返回 numpy BGR 图（同时缓存最近一帧供点击特效显示）"""
        img = self.ctrl.post_screencap().get(wait=True)
        if img is not None:
            self.last_frame = img
            # 预览：定时推送最新帧（点击帧优先，无点击时画面也持续刷新）
            now = time.time()
            if now - self._last_preview_push >= 0.3:
                self._last_preview_push = now
                try:
                    TAP_QUEUE.put((img, None, None))
                except Exception:
                    pass
        return img

    def get_px(self, img, x, y):
        """取像素，numpy 是 BGR → 返回 (r,g,b)"""
        p = img[int(y), int(x)]
        return (int(p[2]), int(p[1]), int(p[0]))

    def color_match(self, rgb, target, tol):
        return (abs(rgb[0] - target[0]) <= tol and
                abs(rgb[1] - target[1]) <= tol and
                abs(rgb[2] - target[2]) <= tol)

    def ocr_region(self, img, reg):
        """区域 OCR，返回文字列表。reg=(x1,y1,x2,y2)"""
        x1, y1, x2, y2 = reg
        w, h = x2 - x1, y2 - y1
        if w <= 0 or h <= 0:
            return []
        try:
            job = self.tasker.post_recognition(
                JRecognitionType.OCR,
                JOCR(expected=[], roi=(x1, y1, w, h), only_rec=False),
                img,
            )
            job.wait()
            texts = []
            td = job.get()
            for nid in td.node_id_list:
                nd = self.tasker.get_node_detail(nid)
                if nd and nd.recognition:
                    for r in nd.recognition.all_results:
                        if hasattr(r, "text") and r.text:
                            texts.append(r.text)
            return texts
        except Exception as e:
            log(f"⚠️ OCR区域异常({reg}): {e}")
            return []

    def region_contains(self, img, reg, keywords):
        texts = self.ocr_region(img, reg)
        for t in texts:
            for k in keywords:
                if k in t:
                    return True
        return False

    def find_template(self, img, reg, threshold=None, max_n=None):
        """模板匹配找加号，返回中心点列表 [(x,y,score), ...]"""
        x1, y1, w, h = reg
        if threshold is None:
            threshold = CFG["PLUS_THRESHOLD"]
        if max_n is None:
            max_n = CFG["PLUS_MAX"]
        try:
            job = self.tasker.post_recognition(
                JRecognitionType.TemplateMatch,
                JTemplateMatch(template=[TPL_FILE], roi=(x1, y1, w, h), threshold=[threshold]),
                img,
            )
            job.wait()
            td = job.get()
            pts = []
            for nid in td.node_id_list:
                nd = self.tasker.get_node_detail(nid)
                if nd and nd.recognition:
                    for r in nd.recognition.all_results:
                        if not hasattr(r, "box") or not hasattr(r, "score"):
                            continue
                        b = r.box
                        # box 可能是 list [x,y,w,h] 或 Rect 对象
                        if isinstance(b, (list, tuple)) and len(b) >= 4:
                            bx, by, bw, bh = b[0], b[1], b[2], b[3]
                        else:
                            bx, by, bw, bh = b.x, b.y, b.w, b.h
                        sc = float(r.score)
                        if sc < threshold:
                            continue   # 过滤低分候选
                        pts.append((bx + bw / 2, by + bh / 2, sc))
            # 去重叠：按分数降序，过滤中心距离 < 30 的重复
            pts.sort(key=lambda p: -p[2])
            picked = []
            for p in pts:
                if all(abs(p[0] - q[0]) > 30 or abs(p[1] - q[1]) > 30 for q in picked):
                    picked.append(p)
                if len(picked) >= max_n:
                    break
            return picked
        except Exception as e:
            log(f"⚠️ 模板匹配异常: {e}")
            return []

    # ---------- 点击（sendevent 直写触摸驱动） ----------
    def raw_tap(self, x, y):
        x, y = int(round(x)), int(round(y))
        self._tid += 1
        dev = CFG["TOUCH_DEV"]
        cmd = (
            f"sendevent {dev} 3 57 {self._tid}; "
            f"sendevent {dev} 3 53 {x}; "
            f"sendevent {dev} 3 54 {y}; "
            f"sendevent {dev} 1 330 1; "
            f"sendevent {dev} 0 0 0; "
            f"sendevent {dev} 3 57 -1; "
            f"sendevent {dev} 1 330 0; "
            f"sendevent {dev} 0 0 0"
        )
        self.shell(f"su -c '{cmd}'")
        # 点击特效：把最近一帧 + 点击坐标推给 GUI 预览显示
        try:
            TAP_QUEUE.put((self.last_frame, x, y))
        except Exception:
            pass

    def raw_swipe(self, x1, y1, x2, y2, steps=10):
        dev = CFG["TOUCH_DEV"]
        self._tid += 1
        cmds = [
            f"sendevent {dev} 3 57 {self._tid}",
            f"sendevent {dev} 3 53 {int(x1)}",
            f"sendevent {dev} 3 54 {int(y1)}",
            f"sendevent {dev} 1 330 1",
            f"sendevent {dev} 0 0 0",
        ]
        for i in range(1, steps + 1):
            xi = int(round(x1 + (x2 - x1) * i / steps))
            yi = int(round(y1 + (y2 - y1) * i / steps))
            cmds.append(f"sleep 0.05; sendevent {dev} 3 53 {xi}; sendevent {dev} 3 54 {yi}; sendevent {dev} 0 0 0")
        cmds.append(f"sleep 0.05; sendevent {dev} 3 57 -1; sendevent {dev} 1 330 0; sendevent {dev} 0 0 0")
        self.shell(f"su -c '{" ; ".join(cmds)}'")

    def back(self):
        self.shell("input keyevent 4")

    def shell(self, cmd):
        """执行 adb shell 命令（常驻连接：一次启动复用，超时自动重连，连续失败回退单次模式）"""
        if self._persist_fallback:
            return self._shell_once(cmd)
        for attempt in range(2):   # 第1次 + 重连后重试1次
            try:
                self._ensure_conn()
                self._ensure_reader()
                marker = "__END__"
                self._shell_proc.stdin.write(f"{cmd}; echo {marker}\n")
                self._shell_proc.stdin.flush()
                out = ""
                deadline = time.time() + 5.0
                while time.time() < deadline:
                    try:
                        line = self._out_q.get(timeout=max(0.05, deadline - time.time()))
                    except queue.Empty:
                        continue   # 没到超时就继续等
                    if line is None:
                        raise RuntimeError("连接已关闭(EOF)")
                    out += line
                    if marker in line:
                        self._shell_fail_count = 0
                        return out
                raise RuntimeError("命令超时 5s")
            except Exception as e:
                self._shell_fail_count += 1
                log(f"⚠️ 常驻shell异常(尝试{attempt + 1}): {e}")
                self._kill_conn()
                if attempt == 0:
                    continue
                log("⚠️ 常驻连接连续失败，本会话退回单次模式")
                self._persist_fallback = True
                return self._shell_once(cmd)
        return None

    def _ensure_conn(self):
        """确保常驻交互式 adb shell 进程存在"""
        if self._shell_proc is None or self._shell_proc.poll() is not None:
            self._shell_proc = subprocess.Popen(
                [self.cfg["adb_path"], "-s", self.cfg["address"], "shell"],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace", bufsize=1,
                creationflags=subprocess.CREATE_NO_WINDOW,   # 打包 exe 时不弹 cmd 窗口
            )
            self._reader_thread = None   # 新进程要重新起读线程
            if self._conn_ever:
                log("🔄 常驻连接已重建")
            else:
                log("✅ 常驻连接已建立")
            self._conn_ever = True

    def _ensure_reader(self):
        """启动 stdout 读线程（输出行进队列，避免管道阻塞）"""
        if self._reader_thread and self._reader_thread.is_alive():
            return
        self._out_q = queue.Queue()
        proc = self._shell_proc

        def _reader():
            try:
                for line in proc.stdout:
                    self._out_q.put(line)
            except Exception:
                pass
            self._out_q.put(None)   # EOF 标记

        self._reader_thread = threading.Thread(target=_reader, daemon=True)
        self._reader_thread.start()

    def _kill_conn(self):
        """杀掉常驻连接，下次自动重建"""
        try:
            if self._shell_proc:
                self._shell_proc.kill()
        except Exception:
            pass
        self._shell_proc = None
        self._reader_thread = None

    def _shell_once(self, cmd):
        """回退模式：每次新建进程执行（原实现，慢但稳）"""
        try:
            subprocess.run(
                [self.cfg["adb_path"], "-s", self.cfg["address"], "shell", cmd],
                capture_output=True, timeout=10,
                creationflags=subprocess.CREATE_NO_WINDOW,   # 打包 exe 时不弹 cmd 窗口
            )
        except Exception as e:
            log(f"⚠️ shell 执行失败: {e}")

    def scroll_down(self):
        log("👆 下滑刷新 (360,900)→(360,400)")
        self.raw_swipe(360, 900, 360, 400)
        time.sleep(CFG["WAIT_SCROLL"] / 1000)

    # ---------- 页面判定 ----------
    def is_on_jijie_page(self):
        """集结页双判定：①"联盟战争"标题 ②"集结"标签背景色"""
        img = self.capture()
        if img is None:
            return False
        try:
            cond1 = self.region_contains(img, CFG["PAGE_TITLE_REG"], ["联盟战争"])
            cx = (CFG["PAGE_BG_REG"][0] + CFG["PAGE_BG_REG"][2]) // 2
            cy = (CFG["PAGE_BG_REG"][1] + CFG["PAGE_BG_REG"][3]) // 2
            px = self.get_px(img, cx, cy)
            cond2 = self.color_match(px, CFG["PAGE_BG_RGB"], CFG["PAGE_BG_TOL"])
            ok = cond1 and cond2
            log(f"📐 集结页判定: 标题={'✓' if cond1 else '✗'} 背景色={px} {'✓' if cond2 else '✗'} → {'在集结页' if ok else '不在'}")
            return ok
        except Exception as e:
            log(f"⚠️ 集结页判定异常: {e}")
            return False

    # ---------- 导航 ----------
    def navigate_to_jijie(self):
        """不在集结页：找主界面'联盟' → 点联盟 → 点联盟战争"""
        log("导航回集结页：先找主界面'联盟'字样...")
        back_count = 0
        found = False
        while back_count < 20:
            if self.stop:
                return False
            img = self.capture()
            if img is not None:
                texts = self.ocr_region(img, CFG["MAIN_LM_REG"])
                found = any("联盟" in t for t in texts)
                log(f"  OCR联盟区: [{texts}] {'→命中' if found else '→未命中'}")
            if found:
                log("✅ 识别到主界面'联盟'字样")
                break
            log(f"未识别到'联盟'，按返回键 (第{back_count + 1}次)")
            self.back()
            back_count += 1
            time.sleep(0.5)
        if not found:
            log("❌ 按返回20次仍未找到'联盟'，停止导航")
            return False
        log(f"点击联盟按钮 {CFG['MAIN_LM_TAP']}")
        self.raw_tap(*CFG["MAIN_LM_TAP"])
        time.sleep(0.2)
        log(f"点击联盟战争按钮 {CFG['LMZ_TAP']}")
        self.raw_tap(*CFG["LMZ_TAP"])
        time.sleep(CFG["WAIT_NAV"] / 1000)
        return True

    # ---------- 车头名判定 ----------
    def is_in_whitelist(self, text):
        if not text:
            return False
        if not self.whitelist:
            return True   # 未限制：所有集结都加
        for w in self.whitelist:
            if w and w in text:
                return w
        return False

    # ---------- 选队伍 + 出征 ----------
    def pick_team(self, img):
        """1-4 队选无感叹号（采样点非橙黄），全有感叹号强制队1"""
        chosen = -1
        for i in range(4):
            px = self.get_px(img, CFG["EXCL_POINTS"][i][0], CFG["EXCL_POINTS"][i][1])
            has_excl = self.color_match(px, CFG["EXCL_RGB"], CFG["EXCL_TOL"])
            log(f"  队{i + 1} 采样={px} {'有感叹号' if has_excl else '空闲'}")
            if not has_excl:
                chosen = i
                break
        if chosen == -1:
            log("⚠️ 1-4队都有感叹号，强制选择队1")
            chosen = 0
        tx, ty = CFG["TEAMS"][chosen]
        log(f"✅ 选择队{chosen + 1} ({tx},{ty})")
        self.raw_tap(tx, ty)

    def go_out(self):
        """点出征 + 弹窗检测（士兵超上限 → 按两次返回）"""
        log(f"点击出征按钮 {CFG['GO_TAP']}")
        self.raw_tap(*CFG["GO_TAP"])
        time.sleep(CFG["WAIT_POPUP"] / 1000)
        img = self.capture()
        if img is not None:
            has_popup = self.region_contains(img, CFG["POPUP_REG"], ["上限", "重新编队", "士兵"])
            if has_popup:
                log("⚠️ 检测到士兵超上限弹窗，按两次返回")
                self.back()
                time.sleep(0.3)
                self.back()
                return "popup"
        return "ok"

    # ---------- 找加号 + 上车 ----------
    def find_and_join(self, img):
        """找绿色加号 → 验证颜色 → OCR 车头名 → 命中白名单 → 直接点击加号
        返回: True=已上车, False=本轮无命中"""
        reg = CFG["PLUS_SEARCH_REG"]
        pts = self.find_template(img, reg)
        if not pts:
            return False
        log(f"🔍 找到 {len(pts)} 个加号候选")

        for i, (pcx, pcy, score) in enumerate(pts):
            if self.stop:
                return False
            # 颜色验证：采样加号左上角 (pcx-12, pcy-12)，亮绿 g>150 且 r<120 才要
            cx, cy = pcx + CFG["PLUS_GREEN_CHECK"][0], pcy + CFG["PLUS_GREEN_CHECK"][1]
            pc = self.get_px(img, cx, cy)
            if not (pc[1] > 150 and pc[0] < 120):
                log(f"⚪ 加号{i + 1} 非绿色({pc})，跳过")
                continue

            # 名字区 OCR（相对加号中心偏移）
            dx1, dy1, dx2, dy2 = CFG["PLUS_NAME_REL"]
            nx1 = max(0, int(pcx + dx1)); ny1 = max(0, int(pcy + dy1))
            nx2 = int(pcx + dx2); ny2 = int(pcy + dy2)
            name_text = " ".join(self.ocr_region(img, (nx1, ny1, nx2, ny2)))
            if name_text:
                log(f"📋 加号{i + 1} 车头: [{name_text}]")

            hit = self.is_in_whitelist(name_text)
            if hit is False:
                continue   # 白名单模式不匹配 → 看下一个加号

            # 命中：直接点击加号（不再点加号左侧）
            log(f"✅ 命中车头 [{hit if hit is not True else '（未限制）'}]，直接点击加号 ({int(pcx)},{int(pcy)})")
            self.raw_tap(pcx, pcy)
            time.sleep(0.05)   # 选择队伍界面等待 50ms，等界面加载

            # 选队伍前判定：若误进"队长"详情页，则点 (594,512) 回到选队伍
            img2 = self.capture()
            if img2 is not None:
                if self.region_contains(img2, (248, 165, 307, 200), ["队长"]):
                    log("⚠️ 误进详情页（识别到“队长”），点击 (594,512) 回选队伍")
                    self.raw_tap(594, 512)
                    img2 = self.capture()
                self.pick_team(img2)
            else:
                log("⚠️ 选队伍前截图失败，直接点队1")
                self.raw_tap(*CFG["TEAMS"][0])
            self.go_out()
            return True
        return False

    # ---------- 主循环 ----------
    def run(self):
        log("==================================================")
        log("无尽冬日自动上车 (MaaFramework GUI 版) 启动")
        log("==================================================")
        round_no = 0
        last_scroll = time.time()
        last_page_check = time.time()

        while not self.stop:
            round_no += 1
            log(f"──── 第 {round_no} 轮 ────")

            # 停止文件检测
            if os.path.exists(STOP_FILE):
                log("⏹ 检测到 stop.txt，退出")
                break

            # 1. 判定集结页
            if not self.is_on_jijie_page():
                if not self.navigate_to_jijie():
                    time.sleep(1)
                    continue
                # 导航后再判定一次，不在则按返回重新导航
                if not self.is_on_jijie_page():
                    log("⚠️ 点联盟战争后仍不在集结页，按返回重新导航")
                    self.back()
                    time.sleep(0.2)
                    continue
                log("✅ 确认在集结页，开始找车头名")
                # 导航进入集结页：下滑三次刷新列表
                log("🔄 导航进入集结页，下滑三次刷新")
                for _ in range(3):
                    self.scroll_down()
            else:
                log("✅ 已在集结页，直接开始找车头名")

            # 2. 找加号循环
            while not self.stop:
                if os.path.exists(STOP_FILE):
                    log("⏹ 检测到 stop.txt，退出")
                    self.stop = True
                    break

                # 每 10 秒下滑一次
                if time.time() - last_scroll >= CFG["SCROLL_INTERVAL"] / 1000:
                    last_scroll = time.time()
                    self.scroll_down()

                # 每 5 秒周期判定是否还在集结页
                if time.time() - last_page_check >= CFG["PAGE_CHECK_INTERVAL"] / 1000:
                    last_page_check = time.time()
                    if not self.is_on_jijie_page():
                        log("⚠️ 周期检查：已不在集结页，返回导航")
                        break

                img = self.capture()
                if img is None:
                    time.sleep(0.05)
                    continue
                joined = self.find_and_join(img)
                if joined:
                    log("🚗 上车成功，自动回到集结页")
                    time.sleep(CFG["WAIT_AFTER_JOIN"] / 1000)
                    break   # 回到主循环重新判定集结页

        log("⏹ 脚本已停止")
